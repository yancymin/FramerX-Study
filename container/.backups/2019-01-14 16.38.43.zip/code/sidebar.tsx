import * as React from 'react'
import { PropertyControls, ControlType } from 'framer'
import styled from 'styled-components'

const BarContainer = styled.div`
  * {
    padding: 0;
    margin: 0;
  }
  width: 100%;
  height: 100%;
  color: #333;
  border-radius: 6px;
  padding: 8px;
  background: #fff;

  .row {
    padding: 8px 20px;
    text-align: left;
    font-size: 13px;
    color: #666666;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;

    &:hover {
      color: black;
      background: #f3f3f3;
      font-weight: bold;
    }
  }
`

// Define type of property
interface Props {
  text: string
}

export class sidebar extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: 'test'
  }

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: 'Text' }
  }

  render() {
    return (
      <BarContainer>
        <div className="row">
          <p>按钮 | button</p>
        </div>
        <div className="row">
          <p>导航栏 | navigation</p>
        </div>
        <div className="row">
          <p>anniu</p>
        </div>
        <div className="row">
          <p>anniu</p>
        </div>
      </BarContainer>
    )
  }
}
